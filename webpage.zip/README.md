# Fantasy WebApp
**This** webapp page is created only for the testing purposes

You can modify information from the *index.html* as:
* Your Name
* Subtitle
* Icons
* Page name
* Fav icons
* Redirected URL's

## Description
This is an HTML-5 based simple webpage
